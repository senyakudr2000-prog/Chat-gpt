package dev.aftershock;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public class Aftershock implements ModInitializer {
    private static final int MAX_COLLAPSE_BLOCKS = 22;

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state) -> {
            if (!(world instanceof ServerWorld serverWorld)) return;
            if (state.isAir() || state.getHardness(world, pos) < 0) return;
            collapseUnsupported(serverWorld, pos, player);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(CommandManager.literal("aftershock")
                .then(CommandManager.literal("collapse").executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayer();
                    BlockPos origin = player.getBlockPos();
                    collapseUnsupported(player.getServerWorld(), origin, player);
                    context.getSource().sendFeedback(() -> Text.literal("§6The structure answers with an aftershock."), false);
                    return 1;
                }))
                .then(CommandManager.literal("help").executes(context -> {
                    context.getSource().sendFeedback(() -> Text.literal("§6Aftershock: §fBreak a supporting block to trigger a nearby structural collapse. Use /aftershock collapse to test it."), false);
                    return 1;
                }))
            )
        );
    }

    private static void collapseUnsupported(ServerWorld world, BlockPos origin, ServerPlayerEntity player) {
        Set<BlockPos> checked = new HashSet<>();
        int spawned = 0;

        // Scan a compact area above and around the broken block. Blocks only detach
        // when they have no solid support directly beneath them.
        for (int y = 0; y <= 5 && spawned < MAX_COLLAPSE_BLOCKS; y++) {
            for (int dx = -2; dx <= 2 && spawned < MAX_COLLAPSE_BLOCKS; dx++) {
                for (int dz = -2; dz <= 2 && spawned < MAX_COLLAPSE_BLOCKS; dz++) {
                    BlockPos candidate = origin.up(y).add(dx, 0, dz);
                    if (!checked.add(candidate.toImmutable())) continue;
                    if (!world.isChunkLoaded(candidate)) continue;

                    BlockState state = world.getBlockState(candidate);
                    if (state.isAir() || state.isOf(Blocks.BEDROCK) || state.getHardness(world, candidate) < 0) continue;
                    if (state.getCollisionShape(world, candidate).isEmpty()) continue;

                    BlockPos below = candidate.down();
                    BlockState support = world.getBlockState(below);
                    boolean hasSupport = !support.isAir() && !support.getCollisionShape(world, below).isEmpty();

                    // Existing gravity blocks are left to vanilla; the mod focuses on
                    // otherwise-stable blocks that lose their support.
                    if (hasSupport || state.getBlock() instanceof net.minecraft.block.FallingBlock) continue;

                    // Keep the effect bounded and make distant blocks less likely to detach.
                    double distance = Math.sqrt(candidate.getSquaredDistance(origin));
                    double chance = Math.max(0.18, 0.82 - distance * 0.12);
                    if (ThreadLocalRandom.current().nextDouble() > chance) continue;

                    world.setBlockState(candidate, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                    FallingBlockEntity falling = FallingBlockEntity.spawnFromBlock(world, candidate, state);
                    if (falling != null) {
                        double awayX = candidate.getX() + 0.5 - player.getX();
                        double awayZ = candidate.getZ() + 0.5 - player.getZ();
                        double length = Math.max(0.001, Math.sqrt(awayX * awayX + awayZ * awayZ));
                        double impulse = 0.10 + ThreadLocalRandom.current().nextDouble() * 0.18;
                        falling.setVelocity(new Vec3d(
                            awayX / length * impulse,
                            0.12 + ThreadLocalRandom.current().nextDouble() * 0.16,
                            awayZ / length * impulse
                        ));
                        spawned++;
                    }
                }
            }
        }

        if (spawned > 0) {
            player.sendMessage(Text.literal("§6Aftershock §7— " + spawned + " blocks lost their footing."), true);
        }
    }
}
