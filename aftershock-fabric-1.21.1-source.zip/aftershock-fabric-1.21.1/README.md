# Aftershock: Structural Physics

**Minecraft Java 1.21.1 · Fabric · Java 21**

Aftershock is a structural-collapse experiment, not a cosmetic ambience mod.

## What it does
- Breaking a block can destabilize nearby blocks that are no longer supported.
- Detached blocks become actual falling block entities, so they fall through the world and collide using Minecraft's entity physics.
- The collapse is bounded to a small area to avoid turning one block break into an unbounded chain reaction.
- The effect applies to solid blocks that would normally stay floating; vanilla gravity blocks such as sand and gravel are left to vanilla.
- A small status message reports how many blocks detached.

## Commands
- `/aftershock help`
- `/aftershock collapse` — test the collapse near your current position.

## Build on GitHub from Android
1. Create a repository on GitHub.
2. Upload the contents of this archive, preserving `.github/workflows/build.yml`.
3. Open **Actions** and run **Build Aftershock**, or commit the files to trigger it.
4. Download the `aftershock-fabric-1.21.1` artifact from the completed workflow.
5. Extract the downloaded artifact and put `aftershock-1.0.0.jar` in the Minecraft `mods` folder.

## Notes
This is a first playable implementation of structural collapse. It does not yet split a block into smaller voxel fragments; the detached pieces are full Minecraft block entities. The GitHub Actions build is the compatibility check for the selected Minecraft/Fabric dependency versions.
