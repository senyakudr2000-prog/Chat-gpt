# Debt Machines — Fabric 1.21.1

A small Minecraft mod inspired by slot-machine/debt gameplay. It is not a mod for the original game.

## Items
- **Slot Machine**: place the block; right-click it while holding a gold nugget to play. Each try costs 1 nugget; outcomes pay 0, 2, 5, or 12 nuggets.
- **Toolbox**: right-click a block while holding it to do a quick job and receive 2–5 gold ingots. Five-minute cooldown.
- **Golden Ticket**: right-click a block to redeem it for a random amount of gold nuggets.
- **Work Contract**: right-click a block to redeem it for 4–10 emeralds.

Find all items in the Functional Blocks creative tab. Requires Minecraft 1.21.1, Fabric Loader, Fabric API, and Java 21.

## Build
Run `./gradlew build` (Linux/macOS) or `gradlew.bat build` (Windows). The jar is created in `build/libs/`.
