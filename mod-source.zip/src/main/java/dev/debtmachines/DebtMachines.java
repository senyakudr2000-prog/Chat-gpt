package dev.debtmachines;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.AbstractBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.server.network.ServerPlayerEntity;

public class DebtMachines implements ModInitializer {
    public static final String MOD_ID = "debt_machines";

    public static final Block SLOT_MACHINE = Registry.register(
        Registries.BLOCK, id("slot_machine"),
        new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(3.0f).requiresTool())
    );

    public static final Item SLOT_MACHINE_ITEM = Registry.register(
        Registries.ITEM, id("slot_machine"),
        new BlockItem(SLOT_MACHINE, new Item.Settings())
    );

    public static final Item TOOLBOX = registerItem("toolbox", new Item(new Item.Settings().maxCount(1)));
    public static final Item GOLDEN_TICKET = registerItem("golden_ticket", new Item(new Item.Settings().maxCount(16)));
    public static final Item WORK_CONTRACT = registerItem("work_contract", new Item(new Item.Settings().maxCount(16)));

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, id(name), item);
    }

    private static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(SLOT_MACHINE_ITEM);
            entries.add(TOOLBOX);
            entries.add(GOLDEN_TICKET);
            entries.add(WORK_CONTRACT);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
            ItemStack held = player.getStackInHand(hand);
            if (held.isOf(TOOLBOX)) {
                if (world.isClient) return ActionResult.SUCCESS;
                if (player.getItemCooldownManager().isCoolingDown(TOOLBOX)) {
                    player.sendMessage(Text.literal("Инструменты ещё восстанавливаются."), true);
                    return ActionResult.SUCCESS;
                }
                player.getItemCooldownManager().set(TOOLBOX, 20 * 60 * 5);
                player.giveItemStack(new ItemStack(Items.GOLD_INGOT, 2 + world.random.nextInt(4)));
                player.sendMessage(Text.literal("Подработка выполнена: ты получил золотые слитки."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8f, 0.9f);
                return ActionResult.SUCCESS;
            }
            if (held.isOf(GOLDEN_TICKET)) {
                if (world.isClient) return ActionResult.SUCCESS;
                held.decrement(1);
                int roll = world.random.nextInt(100);
                int amount = roll < 5 ? 16 : roll < 25 ? 6 : roll < 65 ? 3 : 1;
                player.giveItemStack(new ItemStack(Items.GOLD_NUGGET, amount));
                player.sendMessage(Text.literal("Билет погашен: награда — " + amount + " золотых самородков."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6f, 1.1f);
                return ActionResult.SUCCESS;
            }
            if (held.isOf(WORK_CONTRACT)) {
                if (world.isClient) return ActionResult.SUCCESS;
                held.decrement(1);
                int amount = 4 + world.random.nextInt(7);
                player.giveItemStack(new ItemStack(Items.EMERALD, amount));
                player.sendMessage(Text.literal("Контракт закрыт: награда — " + amount + " изумрудов."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 0.8f, 1.0f);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !world.getBlockState(hit.getBlockPos()).isOf(SLOT_MACHINE)) return ActionResult.PASS;
            if (world.isClient) return ActionResult.SUCCESS;
            ItemStack held = player.getStackInHand(hand);
            if (!held.isOf(Items.GOLD_NUGGET)) {
                player.sendMessage(Text.literal("Автомат принимает 1 золотой самородок за попытку."), true);
                return ActionResult.SUCCESS;
            }
            held.decrement(1);
            int roll = world.random.nextInt(100);
            int payout = roll < 4 ? 12 : roll < 18 ? 5 : roll < 45 ? 2 : 0;
            if (payout > 0) {
                player.giveItemStack(new ItemStack(Items.GOLD_NUGGET, payout));
                player.sendMessage(Text.literal("Автомат: выигрыш " + payout + " золотых самородков!"), false);
                world.playSound(null, hit.getBlockPos(), SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), SoundCategory.BLOCKS, 1.0f, 1.2f);
            } else {
                player.sendMessage(Text.literal("Автомат: пусто. Попробуй контракт или подработку."), false);
                world.playSound(null, hit.getBlockPos(), SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 0.8f, 0.7f);
            }
            return ActionResult.SUCCESS;
        });
    }
}
