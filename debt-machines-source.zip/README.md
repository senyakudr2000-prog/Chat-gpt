# Debt Machines — Fabric 1.21.1

Minecraft mod prototype inspired by slot-machine/debt games.

## Items
- **Slot Machine**: place the block and use a gold nugget on it to play.
- **Toolbox**: use on a block for 1–3 iron ingots, with a 5-minute cooldown.
- **Golden Ticket**: use on a block to boost the next spin's odds.
- **Lucky Charm**: use on the slot machine to boost odds for the next 3 spins.
- **Jackpot Token**: use on the slot machine to guarantee a small payout on the next spin.
- **Work Contract**: use on a block to redeem for 4–10 emeralds.

Items are in the Functional Blocks creative tab. Requires Minecraft 1.21.1, Fabric Loader, Fabric API and Java 21.

## Build
Run `gradle build --no-daemon` from this project directory.
