package dev.debtmachines;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.Block;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DebtMachines implements ModInitializer {
    public static final String MOD_ID = "debt_machines";
    private static final java.util.Map<java.util.UUID, Integer> LUCKY_SPINS = new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.Map<java.util.UUID, Integer> JACKPOT_SPINS = new java.util.concurrent.ConcurrentHashMap<>();

    public static final Block SLOT_MACHINE = Registry.register(
        Registries.BLOCK, id("slot_machine"),
        new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(3.0f).requiresTool())
    );
    public static final Item SLOT_MACHINE_ITEM = Registry.register(
        Registries.ITEM, id("slot_machine"), new BlockItem(SLOT_MACHINE, new Item.Settings())
    );

    public static final Item TOOLBOX = registerItem("toolbox", new Item(new Item.Settings().maxCount(1)));
    public static final Item GOLDEN_TICKET = registerItem("golden_ticket", new Item(new Item.Settings().maxCount(16)));
    public static final Item WORK_CONTRACT = registerItem("work_contract", new Item(new Item.Settings().maxCount(16)));
    public static final Item LUCKY_CHARM = registerItem("lucky_charm", new Item(new Item.Settings().maxCount(8)));
    public static final Item JACKPOT_TOKEN = registerItem("jackpot_token", new Item(new Item.Settings().maxCount(8)));

    private static Item registerItem(String name, Item item) {
        return Registry.register(Registries.ITEM, id(name), item);
    }
    private static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(SLOT_MACHINE_ITEM);
            entries.add(TOOLBOX);
            entries.add(GOLDEN_TICKET);
            entries.add(WORK_CONTRACT);
            entries.add(LUCKY_CHARM);
            entries.add(JACKPOT_TOKEN);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
            ItemStack held = player.getStackInHand(hand);
            BlockPos pos = hit.getBlockPos();

            // Items used on the slot machine alter the next spin.
            if (world.getBlockState(pos).isOf(SLOT_MACHINE)) {
                if (held.isOf(LUCKY_CHARM)) {
                    if (!world.isClient) {
                        held.decrement(1);
                        LUCKY_SPINS.merge(player.getUuid(), 3, Integer::sum);
                        player.sendMessage(Text.literal("Удачный талисман активирован: следующие 3 прокрутки имеют повышенный шанс выигрыша."), false);
                        world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1.0f, 1.3f);
                    }
                    return ActionResult.SUCCESS;
                }
                if (held.isOf(JACKPOT_TOKEN)) {
                    if (!world.isClient) {
                        held.decrement(1);
                        JACKPOT_SPINS.merge(player.getUuid(), 1, Integer::sum);
                        player.sendMessage(Text.literal("Жетон джекпота вставлен: следующая игра гарантирует минимум небольшой выигрыш."), false);
                        world.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), SoundCategory.BLOCKS, 1.0f, 1.4f);
                    }
                    return ActionResult.SUCCESS;
                }
                if (held.isOf(Items.GOLD_NUGGET)) {
                    if (world.isClient) return ActionResult.SUCCESS;
                    held.decrement(1);
                    int lucky = LUCKY_SPINS.getOrDefault(player.getUuid(), 0);
                    if (lucky > 0) {
                        if (lucky == 1) LUCKY_SPINS.remove(player.getUuid());
                        else LUCKY_SPINS.put(player.getUuid(), lucky - 1);
                    }
                    boolean jackpot = JACKPOT_SPINS.getOrDefault(player.getUuid(), 0) > 0;
                    if (jackpot) JACKPOT_SPINS.remove(player.getUuid());

                    int roll = world.random.nextInt(100);
                    int payout;
                    if (jackpot) payout = 2 + world.random.nextInt(4);
                    else if (lucky > 0) payout = roll < 10 ? 12 : roll < 35 ? 5 : roll < 75 ? 2 : 0;
                    else payout = roll < 4 ? 12 : roll < 18 ? 5 : roll < 45 ? 2 : 0;

                    if (payout > 0) {
                        player.giveItemStack(new ItemStack(Items.GOLD_NUGGET, payout));
                        player.sendMessage(Text.literal("Автомат: выигрыш " + payout + " золотых самородков!"), false);
                        world.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), SoundCategory.BLOCKS, 1.0f, 1.2f);
                    } else {
                        player.sendMessage(Text.literal("Автомат: пусто. Попробуй использовать талисман или жетон джекпота."), false);
                        world.playSound(null, pos, SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), SoundCategory.BLOCKS, 0.8f, 0.7f);
                    }
                    return ActionResult.SUCCESS;
                }
                if (held.isEmpty()) {
                    player.sendMessage(Text.literal("Вставь золотой самородок, удачный талисман или жетон джекпота."), true);
                    return ActionResult.SUCCESS;
                }
            }

            if (held.isOf(TOOLBOX)) {
                if (world.isClient) return ActionResult.SUCCESS;
                if (player.getItemCooldownManager().isCoolingDown(TOOLBOX)) {
                    player.sendMessage(Text.literal("Инструменты ещё восстанавливаются."), true);
                    return ActionResult.SUCCESS;
                }
                player.getItemCooldownManager().set(TOOLBOX, 20 * 60 * 5);
                player.giveItemStack(new ItemStack(Items.IRON_INGOT, 1 + world.random.nextInt(3)));
                player.sendMessage(Text.literal("Подработка выполнена: получено железо для обмена."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 0.8f, 0.9f);
                return ActionResult.SUCCESS;
            }
            if (held.isOf(GOLDEN_TICKET)) {
                if (world.isClient) return ActionResult.SUCCESS;
                held.decrement(1);
                LUCKY_SPINS.merge(player.getUuid(), 1, Integer::sum);
                player.sendMessage(Text.literal("Билет активирован: следующая прокрутка получит бонус к шансу."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.6f, 1.1f);
                return ActionResult.SUCCESS;
            }
            if (held.isOf(WORK_CONTRACT)) {
                if (world.isClient) return ActionResult.SUCCESS;
                held.decrement(1);
                player.giveItemStack(new ItemStack(Items.EMERALD, 4 + world.random.nextInt(7)));
                player.sendMessage(Text.literal("Контракт закрыт: награда — изумруды."), false);
                world.playSound(null, player.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 0.8f, 1.0f);
                return ActionResult.SUCCESS;
            }
            return ActionResult.PASS;
        });
    }
}
